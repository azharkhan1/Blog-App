import DrawerMenu from './components/DrawerMenu';
import AppRouter from './routes';
function App() {
  return (
    <AppRouter />
  );
}

export default App;
